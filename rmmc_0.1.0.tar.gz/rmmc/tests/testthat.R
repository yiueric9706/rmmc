library(testthat)
library(rmmc)

test_check("rmmc")

